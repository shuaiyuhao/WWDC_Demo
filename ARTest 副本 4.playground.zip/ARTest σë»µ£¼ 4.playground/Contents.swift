//
//  ARViewController.swift
//  WWDC_Demo
//
//  Created by 帅宇豪 on 2019/3/18.
//  Copyright © 2019 shuaiyuhao. All rights reserved.
//

import UIKit
import SceneKit
import ARKit
import Vision
import PlaygroundSupport

class ARViewController: UIViewController, ARSCNViewDelegate {
    
    let sceneView = ARSCNView()
    let scene = SCNScene()
    
    var visionRequest = [VNRequest]()
    var dispatchQueueML = DispatchQueue(label: "AR_MLTEST")
    let addButton = UIButton()
    let backButton = UIButton()
    let debugTextLabel = UILabel()
    var screenCenter: CGPoint!
    var arText: String = "..."
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        self.view = sceneView
        sceneView.scene = scene
        sceneView.autoenablesDefaultLighting = true
        
        debugTextLabel.frame = CGRect(x: 16, y: 20, width: 343, height: 50)
        debugTextLabel.textAlignment = .center
        debugTextLabel.backgroundColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        sceneView.addSubview(debugTextLabel)
        
        addButton.frame = CGRect(x: 20, y: 607, width: 80, height: 40)
        addButton.setTitle("Add Target", for: UIControl.State())
        addButton.backgroundColor = #colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 1)
        addButton.layer.cornerRadius = 8
        addButton.addTarget(self, action: #selector(addButtonTapped), for: .touchUpInside)
        sceneView.addSubview(addButton)
        
        backButton.frame = CGRect(x: 379, y: 607, width: 80, height: 40)
        backButton.setTitle("Back", for: UIControl.State())
        backButton.backgroundColor = #colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 1)
        backButton.layer.cornerRadius = 8
        backButton.addTarget(self, action: #selector(backButtonTapped), for: .touchUpInside)
        sceneView.addSubview(backButton)
        
        sceneView.delegate = self
        sceneView.showsStatistics = true
        
        
        
        guard let model = try? VNCoreMLModel(for: MobileNet().model) else { return }
        let request = VNCoreMLRequest(model: model, completionHandler: getResult)
        request.imageCropAndScaleOption = VNImageCropAndScaleOption.centerCrop
        visionRequest = [request]
        
        loopCoreML()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = .horizontal
        
        sceneView.session.run(configuration)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        sceneView.session.pause()
    }
    
    @objc func backButtonTapped() {
        self.presentingViewController!.dismiss(animated: true, completion: nil)
    }
    
    @objc func addButtonTapped() {
        let screenCenter = CGPoint(x: self.sceneView.bounds.midX, y: self.sceneView.bounds.midY)
        let hitTest = sceneView.hitTest(screenCenter, types: [.featurePoint])
        
        if let hitTestResult = hitTest.first {
            let transform: matrix_float4x4 = hitTestResult.worldTransform
            let coordinate: SCNVector3 = SCNVector3Make(transform.columns.3.x, transform.columns.3.y, transform.columns.3.z)
            
            let node: SCNNode = createResultNode(arText)
            node.position = coordinate
            sceneView.scene.rootNode.addChildNode(node)
            
        }
        
        
    }
    
    func loopCoreML() {
        dispatchQueueML.async {
            self.updateCoreML()
            
            self.loopCoreML()
        }
    }
    
    func updateCoreML() {
        
        let pixelBuffer: CVPixelBuffer? = (sceneView.session.currentFrame?.capturedImage)
        if pixelBuffer == nil {return}
        
        let ciImage = CIImage(cvPixelBuffer: pixelBuffer!)
        let imageRequestHandler = VNImageRequestHandler(ciImage: ciImage, options: [:])
        
        do {
            try imageRequestHandler.perform(self.visionRequest)
        } catch {
            print(error)
        }
    }
    
    func getResult(request: VNRequest, error: Error?) {
        if error != nil {
            print("Error: " + (error?.localizedDescription)!)
            return
        }
        
        guard let results = request.results as? [VNClassificationObservation] else {
            fatalError("Unexpected runtime error")
        }
        guard let firstObservation = results.first else {return}
        
            var objectName: String = "..."
            objectName = firstObservation.identifier
            print(objectName)
            self.debugTextLabel.text = objectName
            self.arText = objectName
        
    }
    
    func createResultNode(_ text: String) -> SCNNode {
        
        let text = SCNText(string: text, extrusionDepth: 0.01)
        let font = UIFont.systemFont(ofSize: 0.15)
        text.font = font
        text.firstMaterial?.diffuse.contents = UIColor.cyan
        text.firstMaterial?.specular.contents = UIColor.white
        text.firstMaterial?.isDoubleSided = true
        let textNode = SCNNode(geometry: text)
        let (minBound, maxBound) = text.boundingBox
        textNode.pivot = SCNMatrix4MakeTranslation((maxBound.x - minBound.x)/2, minBound.y, 0.01 / 2)
        textNode.scale = SCNVector3Make(0.2, 0.2, 0.2)
        
        let point = SCNSphere(radius: 0.003)
        point.firstMaterial?.diffuse.contents = UIColor.white
        let pointNode = SCNNode(geometry: point)
        
        let resultNode = SCNNode()
        resultNode.addChildNode(textNode)
        resultNode.addChildNode(pointNode)
        
        let billBoardConstraint = SCNBillboardConstraint()
        billBoardConstraint.freeAxes = SCNBillboardAxis.Y
        resultNode.constraints = [billBoardConstraint]
        
        return resultNode
    }
    
}


PlaygroundPage.current.liveView = ARViewController()
