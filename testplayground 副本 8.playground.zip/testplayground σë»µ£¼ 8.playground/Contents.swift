//
//  ViewController.swift
//  WWDC_Demo
//
//  Created by 帅宇豪 on 2019/3/17.
//  Copyright © 2019 shuaiyuhao. All rights reserved.
//

import UIKit
import Vision
import PlaygroundSupport

class ViewController: UIViewController {
    
    //let model = MobileNet()
    let chooseImageButton = UIButton()
    let imageView = UIImageView()
    let cardView = UIView()
    let resultLabel = UILabel()
    let analyseButton = UIButton()
    let arViewButton = UIButton()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let view = UIView()
        view.frame = CGRect(x: 0, y: 0, width: 375, height: 900)
        view.backgroundColor = #colorLiteral(red: 0.83088094, green: 0.9329984188, blue: 0.9917135835, alpha: 1)
        
        arViewButton.frame = CGRect(x: 165, y: 450, width: 153, height: 41)
        arViewButton.setTitle("GO to ARView", for: UIControl.State())
        arViewButton.backgroundColor = #colorLiteral(red: 1, green: 0.9254901961, blue: 0.8235294118, alpha: 1)
        arViewButton.layer.cornerRadius = 12
        arViewButton.layer.shadowOpacity = 0.25
        arViewButton.layer.shadowOffset = CGSize(width: 0, height: 10)
        arViewButton.layer.shadowRadius = 10
        arViewButton.addTarget(self, action: #selector(arViewButtonTapped(sender: )), for: .touchUpInside)
        
        analyseButton.frame = CGRect(x: 165, y: 529, width: 153, height: 41)
        analyseButton.setTitle("Analyse Image", for: UIControl.State())
        analyseButton.backgroundColor = #colorLiteral(red: 0.6941176471, green: 0.7294117647, blue: 0.9725490196, alpha: 1)
        analyseButton.layer.cornerRadius = 12
        analyseButton.layer.shadowOpacity = 0.25
        analyseButton.layer.shadowOffset = CGSize(width: 0, height: 10)
        analyseButton.layer.shadowRadius = 10
        analyseButton.addTarget( self, action: #selector(analyseButtonTapped(sender:)), for: .touchUpInside)
        
        resultLabel.frame = CGRect(x: 155, y: 337, width: 171, height: 33)
        resultLabel.textAlignment = .center
        resultLabel.backgroundColor = #colorLiteral(red: 0.831372549, green: 0.9333333333, blue: 0.9921568627, alpha: 1)
        
        chooseImageButton.frame = CGRect(x: 165, y: 598, width: 153, height: 41)
        chooseImageButton.backgroundColor = #colorLiteral(red: 0.7019607843, green: 0.9215686275, blue: 1, alpha: 1)
        chooseImageButton.setTitle("Choose Image", for: UIControl.State())
        chooseImageButton.layer.cornerRadius = 12
        chooseImageButton.layer.shadowOpacity = 0.25
        chooseImageButton.layer.shadowOffset = CGSize(width: 0, height: 10)
        chooseImageButton.layer.shadowRadius = 10
        chooseImageButton.addTarget(self, action: #selector(chooseImageButtonTapped(sender: )), for: .touchUpInside)
        
        cardView.frame = CGRect(x: 90, y: 38, width: 300, height: 250)
        cardView.backgroundColor = UIColor.cyan
        cardView.layer.cornerRadius = 24
        cardView.layer.shadowOpacity = 0.25
        cardView.layer.shadowOffset = CGSize(width: 0, height: 10)
        cardView.layer.shadowRadius = 10
        
        
        imageView.frame = CGRect(x: 0, y: 0, width: 300, height: 250)
        imageView.layer.cornerRadius = 24
        imageView.backgroundColor = #colorLiteral(red: 0.9764705882, green: 0.8509803922, blue: 0.8823529412, alpha: 1)
        imageView.contentMode = .scaleToFill
        //imageView.image = UIImage(named: "img5")
        
        view.addSubview(cardView)
        view.addSubview(resultLabel)
        view.addSubview(analyseButton)
        view.addSubview(arViewButton)
        cardView.addSubview(imageView)
        view.addSubview(chooseImageButton)
        self.view = view
    }
    
    //    func analyseImage (forImage image: UIImage) -> String? {
    //        if let pixelBuffer = ImageProcessor.pixelBuffer(forImage: image.cgImage!) {
    //            guard let result = try? model.prediction(image: pixelBuffer) else {
    //                fatalError("Unexpected runtime error")
    //            }
    //            print(result.classLabelProbs)
    //            return result.classLabel
    //        }
    //        return nil
    //    }
    
    @objc func arViewButtonTapped(sender: UIButton) {
        self.animateButton(sender)
        performSegue(withIdentifier: "toARView", sender: nil)
    }
    
    @objc func chooseImageButtonTapped(sender: UIButton) {
        self.animateButton(sender)
        let imagePickerController = UIImagePickerController()
        imagePickerController.delegate = self
        print("HI")
        let alert = UIAlertController(title: "Choose Your Image", message: "From camera or library", preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: "Library", style: .default, handler: {(UIAlertAction) in
            imagePickerController.sourceType = .photoLibrary
            self.present(imagePickerController, animated: true, completion: nil)
        }))
        alert.addAction(UIAlertAction(title: "Camera", style: .default, handler: {(UIAlertAction) in
            imagePickerController.sourceType = .camera
            self.present(imagePickerController, animated: true, completion: nil)
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        self.present(alert, animated: true, completion: nil)
    }
    
    @objc func analyseButtonTapped(sender: UIButton) {
        
        
        if let imageToAnalyse = imageView.image {
            
            let pixelBuffer = ImageProcessor.pixelBuffer(forImage: imageToAnalyse.cgImage!)
            guard let model = try? VNCoreMLModel(for: MobileNet().model) else { return }
            let request = VNCoreMLRequest(model: model, completionHandler: getResult)
            
            let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer!, options: [ : ])
            try? handler.perform([request])
        }
        //        if let  imageToAnalyse = imageView.image {
        //            if let analyseImageText = analyseImage(forImage: imageToAnalyse) {
        //                resultLabel.text = analyseImageText
        //            }
        //        }
        self.animateButton(sender)
    }
    
    func getResult(request: VNRequest, error: Error?) {
        guard let results = request.results as? [VNClassificationObservation] else {
            fatalError("Unexpected runtime error")
        }
        guard let firstObservation = results.first else { return }
        let resultText = firstObservation.identifier
        resultLabel.text = resultText
    }
    
    func animateButton(_ button: UIView) {
        UIView.animate(withDuration: 0.1, delay: 0, usingSpringWithDamping: 0.4, initialSpringVelocity: 1, options: .curveEaseIn, animations: {
            button.transform = CGAffineTransform(scaleX: 0.92, y: 0.92)
        }) { (_) in
            UIView.animate(withDuration: 0.3, delay: 0, usingSpringWithDamping: 0.4, initialSpringVelocity: 1, options: .curveEaseIn, animations:{
                button.transform = CGAffineTransform(scaleX: 1, y: 1)
            } , completion: nil)
        }
    }
    
}

extension ViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        if let image = info[.originalImage] as? UIImage{
            imageView.image = image
        }
        
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
}
PlaygroundPage.current.liveView = ViewController()
